file "new.txt" do
	action :create
	content path
end
